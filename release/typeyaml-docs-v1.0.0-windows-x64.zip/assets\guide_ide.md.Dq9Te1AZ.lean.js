import { _ as _export_sfc, o as openBlock, c as createElementBlock, a0 as createStaticVNode } from "./chunks/framework.B5VN8EhM.js";
const __pageData = JSON.parse('{"title":"IDE, formatting, and registry","description":"","frontmatter":{},"headers":[],"relativePath":"guide/ide.md","filePath":"guide/ide.md"}');
const _sfc_main = { name: "guide/ide.md" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, [..._cache[0] || (_cache[0] = [
    createStaticVNode("", 6)
  ])]);
}
const ide = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  ide as default
};
