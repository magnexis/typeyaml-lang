import { _ as _export_sfc, o as openBlock, c as createElementBlock, a0 as createStaticVNode } from "./chunks/framework.B5VN8EhM.js";
const __pageData = JSON.parse('{"title":"CLI guide","description":"","frontmatter":{},"headers":[],"relativePath":"guide/cli.md","filePath":"guide/cli.md"}');
const _sfc_main = { name: "guide/cli.md" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, [..._cache[0] || (_cache[0] = [
    createStaticVNode('<h1 id="cli-guide" tabindex="-1">CLI guide <a class="header-anchor" href="#cli-guide" aria-label="Permalink to &quot;CLI guide&quot;">​</a></h1><table tabindex="0"><thead><tr><th>Command</th><th>Purpose</th></tr></thead><tbody><tr><td><code>taml check &lt;file.taml&gt;</code></td><td>Parse imports and validate contracts without emitting files.</td></tr><tr><td><code>taml check &lt;generated.yaml&gt;</code></td><td>Validate generated YAML syntax and trace its failing output line through <code>&lt;generated.yaml&gt;.map</code>.</td></tr><tr><td><code>taml build &lt;file.taml&gt; -o &lt;dir&gt;</code></td><td>Emit YAML and <code>.yaml.map</code> source-map sidecars.</td></tr><tr><td><code>taml build &lt;file.taml&gt; --stdout</code></td><td>Emit one compiled document to stdout for shell pipelines.</td></tr><tr><td><code>taml build &lt;file.taml&gt; -f json</code></td><td>Emit valid formatted JSON plus <code>.json.map</code> sidecars.</td></tr><tr><td><code>taml watch &lt;file.taml&gt;</code></td><td>Rebuild whenever the source file changes.</td></tr><tr><td><code>taml init [directory]</code></td><td>Create a starter service and registry policy file.</td></tr><tr><td><code>taml doctor</code></td><td>Display local CLI and cache setup details.</td></tr></tbody></table>', 2)
  ])]);
}
const cli = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  cli as default
};
