import { _ as _export_sfc, o as openBlock, c as createElementBlock, a0 as createStaticVNode } from "./chunks/framework.B5VN8EhM.js";
const __pageData = JSON.parse('{"title":"Standard library","description":"","frontmatter":{},"headers":[],"relativePath":"guide/standard-library.md","filePath":"guide/standard-library.md"}');
const _sfc_main = { name: "guide/standard-library.md" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, [..._cache[0] || (_cache[0] = [
    createStaticVNode('<h1 id="standard-library" tabindex="-1">Standard library <a class="header-anchor" href="#standard-library" aria-label="Permalink to &quot;Standard library&quot;">​</a></h1><p>Import built-in infrastructure contracts without duplicating their definitions.</p><div class="language-taml vp-adaptive-theme"><button title="Copy Code" class="copy"></button><span class="lang">taml</span><pre class="shiki shiki-themes github-light github-dark vp-code" tabindex="0"><code><span class="line"><span style="--shiki-light:#D73A49;--shiki-dark:#F97583;">import</span><span style="--shiki-light:#24292E;--shiki-dark:#E1E4E8;"> { Deployment } </span><span style="--shiki-light:#D73A49;--shiki-dark:#F97583;">from</span><span style="--shiki-light:#032F62;--shiki-dark:#9ECBFF;"> &quot;std/k8s&quot;</span></span>\n<span class="line"></span>\n<span class="line"><span style="--shiki-light:#D73A49;--shiki-dark:#F97583;">component</span><span style="--shiki-light:#032F62;--shiki-dark:#9ECBFF;"> &quot;payments&quot;</span><span style="--shiki-light:#D73A49;--shiki-dark:#F97583;"> implements</span><span style="--shiki-light:#24292E;--shiki-dark:#E1E4E8;"> Deployment:</span></span>\n<span class="line"><span style="--shiki-light:#24292E;--shiki-dark:#E1E4E8;">  name: </span><span style="--shiki-light:#032F62;--shiki-dark:#9ECBFF;">&quot;payments&quot;</span></span>\n<span class="line"><span style="--shiki-light:#24292E;--shiki-dark:#E1E4E8;">  image: </span><span style="--shiki-light:#032F62;--shiki-dark:#9ECBFF;">&quot;registry.example/payments:1.0&quot;</span></span></code></pre></div><p>Available modules are <code>std/k8s</code> (<code>Deployment</code>, <code>Service</code>, <code>Ingress</code>), <code>std/github-actions</code> (<code>Workflow</code>, <code>Job</code>, <code>Step</code>), and <code>std/docker-compose</code> (<code>ComposeService</code>).</p>', 4)
  ])]);
}
const standardLibrary = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  standardLibrary as default
};
