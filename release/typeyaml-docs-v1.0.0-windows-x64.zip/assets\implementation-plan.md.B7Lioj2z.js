import { _ as _export_sfc, o as openBlock, c as createElementBlock, a0 as createStaticVNode } from "./chunks/framework.B5VN8EhM.js";
const __pageData = JSON.parse('{"title":"typeYAML implementation plan","description":"","frontmatter":{},"headers":[],"relativePath":"implementation-plan.md","filePath":"implementation-plan.md"}');
const _sfc_main = { name: "implementation-plan.md" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, [..._cache[0] || (_cache[0] = [
    createStaticVNode('<h1 id="typeyaml-implementation-plan" tabindex="-1">typeYAML implementation plan <a class="header-anchor" href="#typeyaml-implementation-plan" aria-label="Permalink to &quot;typeYAML implementation plan&quot;">​</a></h1><blockquote><p><strong>Typed. Structured. Human.</strong></p></blockquote><ol><li>Tokenize indentation-sensitive declarations and scalar field values.</li><li>Parse the source into an AST with line locations.</li><li>Resolve component/interface references and merge service schemas.</li><li>Validate required fields, primitive/literal-union types, and bounds.</li><li>Emit deterministic YAML/JSON and expose <code>check</code>/<code>build</code> commands.</li><li>Add executable examples and regression tests; follow with nested values, imports, LSP, and Kubernetes/GitHub Actions schema packages.</li></ol>', 3)
  ])]);
}
const implementationPlan = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  implementationPlan as default
};
