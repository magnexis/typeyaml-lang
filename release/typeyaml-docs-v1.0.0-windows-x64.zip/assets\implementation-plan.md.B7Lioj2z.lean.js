import { _ as _export_sfc, o as openBlock, c as createElementBlock, a0 as createStaticVNode } from "./chunks/framework.B5VN8EhM.js";
const __pageData = JSON.parse('{"title":"typeYAML implementation plan","description":"","frontmatter":{},"headers":[],"relativePath":"implementation-plan.md","filePath":"implementation-plan.md"}');
const _sfc_main = { name: "implementation-plan.md" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, [..._cache[0] || (_cache[0] = [
    createStaticVNode("", 3)
  ])]);
}
const implementationPlan = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  implementationPlan as default
};
