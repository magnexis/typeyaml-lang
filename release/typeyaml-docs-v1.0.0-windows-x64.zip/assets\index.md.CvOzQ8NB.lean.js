import { _ as _export_sfc, o as openBlock, c as createElementBlock, a0 as createStaticVNode } from "./chunks/framework.B5VN8EhM.js";
const __pageData = JSON.parse('{"title":"","description":"","frontmatter":{"layout":"home","hero":{"name":"typeYAML","text":"Statically typed YAML","tagline":"Stop debugging broken YAML in production.","image":{"src":"/typeyaml-logo.png","alt":"typeYAML logo"},"actions":[{"theme":"brand","text":"Get started","link":"/guide/getting-started"},{"theme":"alt","text":"Language specification","link":"/guide/spec"}]}},"headers":[],"relativePath":"index.md","filePath":"index.md"}');
const _sfc_main = { name: "index.md" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", null, [..._cache[0] || (_cache[0] = [
    createStaticVNode("", 4)
  ])]);
}
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __pageData,
  index as default
};
